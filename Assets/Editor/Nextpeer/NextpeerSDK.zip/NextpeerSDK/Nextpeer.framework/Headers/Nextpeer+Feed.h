/*
 Public Nextpeer API - Feed
 */

#import "NextpeerPublic.h"

@interface Nextpeer (Feed)

/**
 Use this method to open Nextpeer's feed dashboard.
 */
+ (void)openFeedDashboard;

@end
